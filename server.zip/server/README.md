1. Inicializar con
    ```npm run dev```
